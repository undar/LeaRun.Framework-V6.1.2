﻿angular.module('starter.controllers', [])
.controller(pagecac4e871-7de5-7786-8364-19a8cd247168'Ctrl',['$scope',
function ($scope,) {};
}])
;

