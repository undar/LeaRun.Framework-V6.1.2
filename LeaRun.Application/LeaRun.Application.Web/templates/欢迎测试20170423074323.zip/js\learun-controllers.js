﻿angular.module('starter.controllers', [])
.controller(page44551c98-1676-f8a2-988f-799102337c31'Ctrl',['$scope',
function ($scope,) {};
}])
;

